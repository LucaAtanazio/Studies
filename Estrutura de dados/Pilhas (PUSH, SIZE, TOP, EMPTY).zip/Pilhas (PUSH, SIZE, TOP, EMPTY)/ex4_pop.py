print("POP (Desfazer alterações)")
alteracoes = ["adicionar função", "renomear variável", "ajustar identação", "remover comentário"]
print("Desfazendo:", alteracoes.pop())
print("Desfazendo:", alteracoes.pop())
print("Desfazendo:", alteracoes.pop())
print("Alterações restantes:", alteracoes)

print("\nPOP ATÉ ESVAZIAR")
pilha = [100, 200, 300]
while len(pilha) > 0:
    print("\nElemento desempilhado:", pilha.pop())
    print("Pilha agora:", pilha)