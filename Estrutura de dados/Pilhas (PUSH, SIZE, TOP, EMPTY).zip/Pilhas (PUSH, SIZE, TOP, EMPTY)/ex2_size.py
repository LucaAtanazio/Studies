print("SIZE (Documentos para impressão)")
documentos = ["Contrato.pdf", "Relatório.docx", "Proposta.xlsx"]
print("Número de documentos na fila (SIZE):", len(documentos))

print("\n SIZE APÓS OPERAÇÕES")
pilha = [7, 14, 21]
pilha.append(28)
pilha.append(35)
pilha.pop()
print("Tamanho final da pilha (SIZE):", len(pilha))