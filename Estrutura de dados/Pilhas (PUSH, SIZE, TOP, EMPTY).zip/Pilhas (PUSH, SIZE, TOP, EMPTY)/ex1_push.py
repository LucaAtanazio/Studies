print("PUSH (Histórico de navegação)")
historico = []
historico.append("google.com")
historico.append("youtube.com")
historico.append("github.com")
print("Histórico de navegação (PUSH):", historico)

print("\n PUSH COM INPUT")
pilha = []
for i in range(3):
    numero = int(input(f"Digite o {i+1}º número para empilhar (PUSH): "))
    pilha.append(numero)
print("Pilha após os PUSHs:", pilha)