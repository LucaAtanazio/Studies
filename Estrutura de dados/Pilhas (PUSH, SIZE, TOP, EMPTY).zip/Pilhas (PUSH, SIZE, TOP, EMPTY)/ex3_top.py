print("TOP (Ações no editor)")
acoes = ["digitar 'Olá!'", "negrito", "inserir imagem", "centralizar texto"]
print("Última ação feita (TOP):", acoes[-1])

print("\n VER TOP SEM ALTERAR")
pilha = [1, 3, 5, 7, 9]
print("Pilha antes do TOP:", pilha)
print("Topo da pilha (TOP):", pilha[-1])
print("Pilha depois do TOP:", pilha)

print("\n Tabela de índices:")
print("-----------------------------------------------")
print("| Elemento | Índice Positivo | Índice Negativo |")
print("-----------------------------------------------")
for i, elem in enumerate(pilha):
    print(f"| {elem:<8} | {i:<14} | {-len(pilha)+i:<14} |")
print("-----------------------------------------------")