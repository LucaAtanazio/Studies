print("EMPTY (Chamados técnicos) ")
chamados = []
if len(chamados) == 0:
    print("Nenhum chamado urgente (EMPTY)")

print("\nVERIFICAR EMPTY ")
pilha = [11, 22]
pilha.pop()
pilha.pop()
if len(pilha) == 0:
    print("Pilha vazia (EMPTY)")